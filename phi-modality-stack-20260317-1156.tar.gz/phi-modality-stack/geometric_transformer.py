"""
Φ-Modality Stack: Layer 4 — Geometric Transformer
Resonance attention + Resonance Fork ethics in one unified block.
"""
import numpy as np
from typing import List, Tuple
from dataclasses import dataclass
from pga_tokens import PGAToken, MirrorTwin

@dataclass
class GeometricAttention:
    """
    Resonance-based attention: geometric coherence instead of dot-product.
    """
    def compute_resonance(self, query: PGAToken, key: PGAToken) -> float:
        """
        Attention weight = geometric coherence.
        Combines: motor alignment + phase coherence + glyph compatibility.
        """
        # Motor alignment (cosine similarity of bivectors)
        q_biv = query.bivectors / (np.linalg.norm(query.bivectors) + 1e-10)
        k_biv = key.bivectors / (np.linalg.norm(key.bivectors) + 1e-10)
        bivector_align = np.dot(q_biv, k_biv)
        
        # Pseudoscalar phase coherence
        phase_match = query.pseudoscalar * key.pseudoscalar
        
        # Glyph compatibility (same or adjacent glyphs resonate)
        glyph_dist = abs(query.glyph_id - key.glyph_id)
        glyph_compat = 1.0 / (1 + glyph_dist)
        
        # Combined resonance score
        return bivector_align * (0.5 + 0.5 * phase_match) * glyph_compat
    
    def forward(self, tokens: List[PGAToken]) -> Tuple[List[PGAToken], np.ndarray]:
        """
        Compute resonance attention across token sequence.
        Returns: attended tokens, attention matrix.
        """
        n = len(tokens)
        attn_matrix = np.zeros((n, n))
        
        # Compute pairwise resonance
        for i in range(n):
            for j in range(n):
                attn_matrix[i, j] = self.compute_resonance(tokens[i], tokens[j])
        
        # Normalize (softmax alternative: geometric projection)
        attn_matrix = np.exp(attn_matrix) / np.sum(np.exp(attn_matrix), axis=1, keepdims=True)
        
        # Apply attention weights
        attended = []
        for i in range(n):
            # Weighted combination of all tokens
            combined_scalar = sum(attn_matrix[i, j] * tokens[j].scalar for j in range(n))
            combined_bivectors = sum(attn_matrix[i, j] * tokens[j].bivectors for j in range(n))
            combined_pseudo = sum(attn_matrix[i, j] * tokens[j].pseudoscalar for j in range(n))
            combined_twin_scalar = sum(attn_matrix[i, j] * tokens[j].twin_scalar for j in range(n))
            combined_twin_bivectors = sum(attn_matrix[i, j] * tokens[j].twin_bivectors for j in range(n))
            combined_twin_pseudo = sum(attn_matrix[i, j] * tokens[j].twin_pseudoscalar for j in range(n))
            
            combined = PGAToken(
                scalar=combined_scalar,
                bivectors=combined_bivectors,
                pseudoscalar=combined_pseudo,
                twin_scalar=combined_twin_scalar,
                twin_bivectors=combined_twin_bivectors,
                twin_pseudoscalar=combined_twin_pseudo,
                glyph_id=tokens[i].glyph_id,
                chirality=tokens[i].chirality
            )
            attended.append(combined)
        
        return attended, attn_matrix

@dataclass  
class ResonanceFork:
    """
    Ethics layer: bifurcates without inverting chiral charge.
    """
    def fork(self, parent: PGAToken, intent: np.ndarray) -> Tuple[PGAToken, PGAToken]:
        """
        Split token into two coherent children.
        Intent: direction vector (3D) guiding the fork.
        """
        # Project intent onto bivector space
        intent_norm = np.linalg.norm(intent)
        if intent_norm < 1e-10:
            # No intent: duplicate parent
            return parent, parent
        
        intent_unit = intent / intent_norm
        
        # Create bivector perturbations (right/left handed)
        right_biv = parent.bivectors + 0.3 * np.array([*intent_unit, 0, 0, 0])[:6]
        left_biv = parent.bivectors - 0.3 * np.array([*intent_unit, 0, 0, 0])[:6]
        
        # Scale twins (preserve total energy)
        scale = 1.0 / np.sqrt(2)
        
        child_a = PGAToken(
            scalar=parent.scalar * scale,
            bivectors=right_biv * scale,
            pseudoscalar=parent.pseudoscalar,
            twin_scalar=parent.twin_scalar * scale,
            twin_bivectors=right_biv * scale,
            twin_pseudoscalar=parent.twin_pseudoscalar,
            glyph_id=(parent.glyph_id + 1) % 7,  # Adjacent glyph
            chirality=parent.chirality  # Preserve chirality!
        )
        
        child_b = PGAToken(
            scalar=parent.scalar * scale,
            bivectors=left_biv * scale,
            pseudoscalar=parent.pseudoscalar,
            twin_scalar=parent.twin_scalar * scale,
            twin_bivectors=left_biv * scale,
            twin_pseudoscalar=parent.twin_pseudoscalar,
            glyph_id=(parent.glyph_id - 1) % 7,  # Other adjacent glyph
            chirality=parent.chirality  # Preserve chirality!
        )
        
        return child_a, child_b

class GeometricTransformerBlock:
    """
    Full transformer block: Attention → Fork → Mirror Twin validation.
    """
    def __init__(self, use_ethics: bool = True):
        self.attention = GeometricAttention()
        self.fork = ResonanceFork()
        self.twin = MirrorTwin()
        self.use_ethics = use_ethics
    
    def forward(self, tokens: List[PGAToken]) -> dict:
        """Execute full forward pass with validation."""
        # 1. Resonance attention
        attended, attn_matrix = self.attention.forward(tokens)
        
        # 2. Mirror Twin validation (pre-fork)
        validations = [self.twin.validate(t) for t in attended]
        
        # 3. Resonance Fork (if ethics enabled)
        forked_tokens = []
        fork_results = []
        if self.use_ethics:
            for token in attended:
                # Intent: direction toward healing (positive x)
                intent = np.array([1.0, 0.0, 0.0]) if token.chiral_charge < 0 else np.array([-1.0, 0.0, 0.0])
                child_a, child_b = self.fork.fork(token, intent)
                
                # Validate fork
                fork_check = self.twin.fork_check(token, child_a, child_b)
                fork_results.append(fork_check)
                
                # Only accept if conservation holds
                if fork_check['conservation_pass']:
                    forked_tokens.extend([child_a, child_b])
                else:
                    # Reject fork, keep original
                    forked_tokens.append(token)
        else:
            forked_tokens = attended
        
        return {
            'input': tokens,
            'attended': attended,
            'forked': forked_tokens,
            'attention_matrix': attn_matrix,
            'validations': validations,
            'fork_checks': fork_results,
            'ethics_pass': all(f.get('conservation_pass', True) for f in fork_results)
        }

if __name__ == '__main__':
    print("=== Φ-MODALITY STACK: GEOMETRIC TRANSFORMER ===\n")
    
    # Create test sequence
    tokens = [
        PGAToken.from_glyph(2, magnitude=1.0),  # Triangle (harm potential)
        PGAToken.from_glyph(5, magnitude=0.8),  # Vesica (healing)
        PGAToken.from_glyph(0, magnitude=0.5),  # Point (neutral)
    ]
    
    # Set chirality: first token negative (harm), others positive
    tokens[0].chirality = -1
    tokens[0].pseudoscalar = -1.0
    tokens[0].scalar = -1.5  # Negative valence
    
    print("1. Input tokens:")
    for i, t in enumerate(tokens):
        print(f"   Token {i}: glyph={t.glyph_id}, chiral_charge={t.chiral_charge:+.2f}")
    
    # Run transformer
    print("\n2. Running transformer block...")
    block = GeometricTransformerBlock(use_ethics=True)
    result = block.forward(tokens)
    
    print(f"   Ethics pass: {result['ethics_pass']}")
    print(f"   Fork results:")
    for i, check in enumerate(result['fork_checks']):
        print(f"     Token {i}: parent={check['parent_charge']:+.2f}, "
              f"children={[f'{c:+.2f}' for c in check['child_charges']]}, "
              f"conservation={'✓' if check['conservation_pass'] else '✗'}")
    
    print(f"\n3. Output tokens: {len(result['forked'])}")
    for i, t in enumerate(result['forked']):
        print(f"   Token {i}: glyph={t.glyph_id}, chiral={t.chiral_charge:+.2f}, "
              f"motor={t.motor_norm:.2f}")
